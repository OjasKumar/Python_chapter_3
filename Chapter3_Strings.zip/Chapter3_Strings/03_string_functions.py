story = "once upon a time there was a youtuber named Harry who uplaoded python course with notes"

# String Functions
print(len(story)) # --> this prints the number of characters
print(story.endswith("notes")) # --> this checks whether the string ends with the text in double quotations.
print(story.count("wa")) # --> this tell how many times the character occurs which we put in double quotations.
print(story.capitalize()) # --> Captitalizes only the first letter of the string.
print(story.find("upon")) # --> Only tells of the first occurence
print(story.replace("Harry", "Ojas")) # --> you have to specify after commas replaces all occurences
