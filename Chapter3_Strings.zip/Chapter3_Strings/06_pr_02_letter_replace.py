letter = ''' Dear <| NAME |>,
You are selected!
<| DATE|> '''

a = input("Enter your name: ")
b = input("Enter today's date: ")

letter = letter.replace("NAME", a)
letter = letter.replace("DATE", b)

print(letter)
