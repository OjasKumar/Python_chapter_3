string = "My name is Ojas and i am learning python  and this  is  amazing!!"

print(string)
print(string.replace("  ", " "))