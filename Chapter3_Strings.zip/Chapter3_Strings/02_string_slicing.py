# greeting = "Good Morning, "
# name = "Ojas"
# print(type(name))

# Concatenating 2 strings
# c = greeting + name
name = "Ojas"
# print(c) 
# print(name[3])
# name[3] = "d" --> Does not work

# print(name[1:4])
# print(name[:4]) # is same as name [0:4]
# print(name[1:]) # is same as name [1:4(or last number of the string)]
# c = name[-4:-1] # is same as [1:4]
# print(c)

name = "OjasIsGood"
d = name[0::3]
print(d)