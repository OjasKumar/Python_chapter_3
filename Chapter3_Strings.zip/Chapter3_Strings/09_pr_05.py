letter = "Dear Harry,This Python course is nice. Thanks!"

letter = "Dear Harry,\n\tThis Python course is nice.\nThanks!"

print(letter)