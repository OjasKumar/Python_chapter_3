a = input("Please enter your name:\n")
print("Good afternoon", a) 